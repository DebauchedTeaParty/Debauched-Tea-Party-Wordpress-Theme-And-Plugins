=== RABT-Web Chat ===
Contributors: Debauched Tea Party
Tags: irc, chat, websocket, real-time, messaging
Requires at least: 5.0
Tested up to: 6.8
Requires PHP: 7.4
Stable tag: 1.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html
Update URI: false

WebSocket IRC client for WordPress with real-time messaging, private chats, and desktop notifications.

== Description ==

RABT-Web Chat is a modern, WebSocket-based IRC client designed specifically for WordPress websites. This plugin enables real-time IRC chat functionality directly within WordPress pages and posts using a simple shortcode.

= Key Features =

* Real-time messaging via WebSocket connections
* Private messaging support with notification badges
* Desktop notifications for new messages
* Multiple theme support (light/dark modes)
* User presence indicators and online user lists
* Channel and private message management
* Responsive design for mobile and desktop
* Secure WebSocket connections (WSS support)

= Technical Requirements =

* WebSocket-enabled IRC server (UnrealIRCd recommended)
* WordPress 5.0 or higher
* PHP 7.4 or higher
* Modern web browser with WebSocket support

== Installation ==

1. Upload the plugin files to `/wp-content/plugins/rabt-web-chat/`
2. Activate the plugin through the 'Plugins' screen in WordPress
3. Configure your WebSocket IRC server in Settings > RABT-Web Chat
4. Add `[web_irc_client]` shortcode to any page or post

== Frequently Asked Questions ==

= What IRC servers are supported? =

Any WebSocket-enabled IRC server. UnrealIRCd is recommended and tested.

= Do I need my own IRC server? =

Yes, you need access to a WebSocket-enabled IRC server or network.

== Changelog ==

= 1.0.0 =
* Rebranded to RABT-Web Chat by Debauched Tea Party
* Custom theme styling matching Debauched Tea Party website
* Role badges with colored indicators (Owner, Admin, Op, HalfOp, Voice)
* Users sorted by role hierarchy, then alphabetically
* Full height layout between navigation and radio player
* Disabled automatic updates to prevent overwriting customizations

