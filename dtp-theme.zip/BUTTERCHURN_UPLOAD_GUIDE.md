# How to Upload Butterchurn Files

## Quick Start

1. Go to **Appearance > Theme Settings** in WordPress admin
2. Scroll to **"Butterchurn Library Files"** section
3. Upload the three required files
4. Click **"Upload Files"**

## Step-by-Step Instructions

### Step 1: Locate Your Butterchurn Files

The Butterchurn files should be in your React project:
- `public/lib/butterchurn.min.js`
- `public/lib/butterchurnPresets.min.js`
- `public/lib/butterchurnPresetsExtra.min.js`

### Step 2: Upload via WordPress Admin

1. **Go to Appearance > Theme Settings** in your WordPress admin dashboard
2. You'll see the **"Butterchurn Library Files"** section
3. Check the status table to see which files are present/missing
4. Use the file upload form to upload each file:
   - Click "Choose File" next to **Butterchurn Core** and select `butterchurn.min.js`
   - Click "Choose File" next to **Butterchurn Presets** and select `butterchurnPresets.min.js`
   - Click "Choose File" next to **Butterchurn Presets Extra** and select `butterchurnPresetsExtra.min.js`
5. Click **"Upload Files"** button
6. The status table will update to show ✓ Present for each uploaded file

### Step 3: Verify Upload

After uploading, you should see:
- ✓ All required files are present (green notice)
- Status table showing "✓ Present" for all three files
- File sizes displayed in the table

### Step 4: Test the Visualizer

1. Go to your visualizer page
2. Start playing the radio
3. Open browser console (F12) and look for:
   - `[DTP Visualizer] All dependencies loaded!`
   - `[DTP Visualizer] Initialization complete`
   - If you see errors about missing Butterchurn, the files weren't uploaded correctly

## File Location

Files will be stored at:
```
/wp-content/themes/dtp-theme/assets/lib/butterchurn.min.js
/wp-content/themes/dtp-theme/assets/lib/butterchurnPresets.min.js
/wp-content/themes/dtp-theme/assets/lib/butterchurnPresetsExtra.min.js
```

## Troubleshooting

### Files Not Uploading

- Check file permissions on your server
- Ensure files are `.js` format
- Check file size (max 10MB per file)
- Try uploading one file at a time

### Visualizer Still Not Working

1. **Check browser console** for error messages
2. **Verify files exist**: Go to Appearance > Theme Settings and check the status table
3. **Clear browser cache** and WordPress cache
4. **Check WebGL2 support**: Your browser must support WebGL2

### Console Errors

- `Butterchurn library not loaded` → Files not uploaded or wrong path
- `WebGL2 not available` → Browser doesn't support WebGL2
- `Audio analyzer not available` → Radio player not initialized

## Alternative: Manual Upload via FTP

If the WordPress upload doesn't work, you can manually upload files via FTP/SFTP:

1. Connect to your server via FTP
2. Navigate to `/wp-content/themes/dtp-theme/assets/lib/`
3. Create the `lib` folder if it doesn't exist
4. Upload the three files:
   - `butterchurn.min.js`
   - `butterchurnPresets.min.js`
   - `butterchurnPresetsExtra.min.js`
5. Set file permissions to 644
6. Refresh the Appearance > Theme Settings page to verify

