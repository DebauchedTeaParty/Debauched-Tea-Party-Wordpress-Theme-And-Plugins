<?php
/**
 * Debauched Tea Party Theme Functions
 *
 * @package DTP_Theme
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

/**
 * Theme Setup
 */
function dtp_theme_setup() {
    // Add theme support
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
    add_theme_support('html5', array(
        'search-form',
        'comment-form',
        'comment-list',
        'gallery',
        'caption',
    ));
    
    // Register navigation menus
    register_nav_menus(array(
        'primary' => __('Primary Menu', 'dtp-theme'),
    ));
}
add_action('after_setup_theme', 'dtp_theme_setup');

/**
 * Enqueue Theme Styles and Scripts
 */
function dtp_theme_scripts() {
    $theme_version = '1.0.1';
    
    // Theme styles
    wp_enqueue_style('dtp-theme-style', get_stylesheet_uri(), array(), $theme_version);
    
    // Radio Player styles
    wp_enqueue_style(
        'dtp-radio-player-style',
        get_template_directory_uri() . '/assets/css/radio-player.css',
        array(),
        $theme_version
    );
    
    // Theme JavaScript for visualizer page
    wp_enqueue_script(
        'dtp-theme-script',
        get_template_directory_uri() . '/js/theme.js',
        array('jquery'),
        $theme_version,
        true
    );
    
    // Radio Player JavaScript
    wp_enqueue_script(
        'dtp-radio-player-script',
        get_template_directory_uri() . '/assets/js/radio-player.js',
        array('jquery'),
        $theme_version,
        true
    );
    
    // Localize script with settings
    wp_localize_script('dtp-radio-player-script', 'dtpRadioPlayer', array(
        'apiUrl' => get_theme_mod('dtp_radio_api_url', 'https://radio.debauchedtea.party/api'),
        'apiKey' => get_theme_mod('dtp_radio_api_key', ''),
        'defaultVolume' => get_theme_mod('dtp_radio_default_volume', 0.5),
        'defaultStation' => get_theme_mod('dtp_radio_default_station', '1'),
        'ajaxUrl' => admin_url('admin-ajax.php'),
        'nonce' => wp_create_nonce('dtp_radio_player_nonce'),
    ));
}
add_action('wp_enqueue_scripts', 'dtp_theme_scripts');

/**
 * Add body classes for theme customization
 */
function dtp_body_classes($classes) {
    $classes[] = 'dtp-theme';
    return $classes;
}
add_filter('body_class', 'dtp_body_classes');

/**
 * Elementor Compatibility
 */
function dtp_elementor_support() {
    // Ensure Elementor works properly with our theme
    add_theme_support('elementor');
}
add_action('after_setup_theme', 'dtp_elementor_support');

/**
 * Add custom logo support
 */
function dtp_custom_logo_setup() {
    add_theme_support('custom-logo', array(
        'height'      => 50,
        'width'       => 200,
        'flex-height' => true,
        'flex-width'  => true,
    ));
}
add_action('after_setup_theme', 'dtp_custom_logo_setup');

/**
 * WordPress Customizer Settings
 */
function dtp_customize_register($wp_customize) {
    // Social Media Section
    $wp_customize->add_section('dtp_social_media', array(
        'title'    => __('Social Media Links', 'dtp-theme'),
        'priority' => 30,
    ));
    
    // GitHub URL
    $wp_customize->add_setting('dtp_github_url', array(
        'default'           => 'https://github.com/DebauchedTeaParty',
        'sanitize_callback' => 'esc_url_raw',
    ));
    $wp_customize->add_control('dtp_github_url', array(
        'label'    => __('GitHub URL', 'dtp-theme'),
        'section'  => 'dtp_social_media',
        'type'     => 'url',
    ));
    
    // Twitter/X URL
    $wp_customize->add_setting('dtp_twitter_url', array(
        'default'           => 'https://x.com/DebauchedTea',
        'sanitize_callback' => 'esc_url_raw',
    ));
    $wp_customize->add_control('dtp_twitter_url', array(
        'label'    => __('Twitter/X URL', 'dtp-theme'),
        'section'  => 'dtp_social_media',
        'type'     => 'url',
    ));
    
    // Discord URL
    $wp_customize->add_setting('dtp_discord_url', array(
        'default'           => 'https://discord.gg/xn7EsByKUp',
        'sanitize_callback' => 'esc_url_raw',
    ));
    $wp_customize->add_control('dtp_discord_url', array(
        'label'    => __('Discord URL', 'dtp-theme'),
        'section'  => 'dtp_social_media',
        'type'     => 'url',
    ));
    
    // Show/Hide Social Icons
    $wp_customize->add_setting('dtp_show_social_icons', array(
        'default'           => true,
        'sanitize_callback' => 'wp_validate_boolean',
    ));
    $wp_customize->add_control('dtp_show_social_icons', array(
        'label'    => __('Show Social Media Icons', 'dtp-theme'),
        'section'  => 'dtp_social_media',
        'type'     => 'checkbox',
    ));
    
    // Navigation Section
    $wp_customize->add_section('dtp_navigation', array(
        'title'    => __('Navigation Settings', 'dtp-theme'),
        'priority' => 25,
    ));
    
    // Show/Hide Logo
    $wp_customize->add_setting('dtp_show_logo', array(
        'default'           => true,
        'sanitize_callback' => 'wp_validate_boolean',
    ));
    $wp_customize->add_control('dtp_show_logo', array(
        'label'    => __('Show Logo', 'dtp-theme'),
        'section'  => 'dtp_navigation',
        'type'     => 'checkbox',
    ));
    
    // Radio Player Section
    $wp_customize->add_section('dtp_radio_player', array(
        'title'    => __('Radio Player Settings', 'dtp-theme'),
        'priority' => 35,
    ));
    
    // Show/Hide Radio Player
    $wp_customize->add_setting('dtp_show_radio_player', array(
        'default'           => true,
        'sanitize_callback' => 'wp_validate_boolean',
    ));
    $wp_customize->add_control('dtp_show_radio_player', array(
        'label'    => __('Show Radio Player', 'dtp-theme'),
        'section'  => 'dtp_radio_player',
        'type'     => 'checkbox',
    ));
    
    // Radio API URL
    $wp_customize->add_setting('dtp_radio_api_url', array(
        'default'           => 'https://radio.debauchedtea.party/api',
        'sanitize_callback' => 'esc_url_raw',
    ));
    $wp_customize->add_control('dtp_radio_api_url', array(
        'label'    => __('Radio API URL', 'dtp-theme'),
        'section'  => 'dtp_radio_player',
        'type'     => 'url',
        'description' => __('Base URL for the radio API', 'dtp-theme'),
    ));
    
    // Radio API Key
    $wp_customize->add_setting('dtp_radio_api_key', array(
        'default'           => '',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('dtp_radio_api_key', array(
        'label'    => __('Radio API Key', 'dtp-theme'),
        'section'  => 'dtp_radio_player',
        'type'     => 'text',
        'description' => __('API key for authentication (optional)', 'dtp-theme'),
    ));
    
    // Default Volume
    $wp_customize->add_setting('dtp_radio_default_volume', array(
        'default'           => 0.5,
        'sanitize_callback' => 'floatval',
    ));
    $wp_customize->add_control('dtp_radio_default_volume', array(
        'label'    => __('Default Volume', 'dtp-theme'),
        'section'  => 'dtp_radio_player',
        'type'     => 'number',
        'input_attrs' => array(
            'min' => 0,
            'max' => 1,
            'step' => 0.1,
        ),
        'description' => __('Default volume level (0.0 to 1.0)', 'dtp-theme'),
    ));
    
    // Default Station ID
    $wp_customize->add_setting('dtp_radio_default_station', array(
        'default'           => '1',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('dtp_radio_default_station', array(
        'label'    => __('Default Station ID', 'dtp-theme'),
        'section'  => 'dtp_radio_player',
        'type'     => 'text',
        'description' => __('Default station ID to play', 'dtp-theme'),
    ));
}
add_action('customize_register', 'dtp_customize_register');

/**
 * Add admin bar spacing when logged in
 */
function dtp_admin_bar_spacing() {
    if (is_admin_bar_showing()) {
        ?>
        <style>
            .dtp-navigation {
                top: 32px !important;
            }
            @media screen and (max-width: 782px) {
                .dtp-navigation {
                    top: 46px !important;
                }
            }
        </style>
        <?php
    }
}
add_action('wp_head', 'dtp_admin_bar_spacing');

/**
 * Visualizer Settings - Add admin menu
 */
function dtp_visualizer_admin_menu() {
    add_theme_page(
        __('Visualizer Settings', 'dtp-theme'),
        __('Theme Settings', 'dtp-theme'),
        'manage_options',
        'dtp-theme-settings',
        'dtp_visualizer_admin_page'
    );
}
add_action('admin_menu', 'dtp_visualizer_admin_menu');

/**
 * Handle Butterchurn file uploads
 */
function dtp_handle_butterchurn_uploads() {
    if (!isset($_POST['dtp_upload_butterchurn_files']) || !check_admin_referer('dtp_upload_butterchurn_files', 'dtp_butterchurn_upload_nonce')) {
        return;
    }
    
    if (!current_user_can('manage_options')) {
        wp_die(__('You do not have sufficient permissions to access this page.', 'dtp-theme'));
    }
    
    $lib_dir = get_template_directory() . '/assets/lib/';
    
    // Ensure directory exists
    if (!file_exists($lib_dir)) {
        wp_mkdir_p($lib_dir);
    }
    
    $allowed_files = array(
        'butterchurn_file' => 'butterchurn.min.js',
        'butterchurn_presets_file' => 'butterchurnPresets.min.js',
        'butterchurn_presets_extra_file' => 'butterchurnPresetsExtra.min.js',
    );
    
    $uploaded = 0;
    $errors = array();
    
    foreach ($allowed_files as $field_name => $target_filename) {
        if (!isset($_FILES[$field_name]) || $_FILES[$field_name]['error'] !== UPLOAD_ERR_OK) {
            continue;
        }
        
        $file = $_FILES[$field_name];
        
        // Validate file type
        $file_ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
        if ($file_ext !== 'js') {
            $errors[] = sprintf(__('%s must be a .js file', 'dtp-theme'), $file['name']);
            continue;
        }
        
        // Validate file size (max 10MB)
        if ($file['size'] > 10 * 1024 * 1024) {
            $errors[] = sprintf(__('%s is too large (max 10MB)', 'dtp-theme'), $file['name']);
            continue;
        }
        
        // Move uploaded file
        $target_path = $lib_dir . $target_filename;
        if (move_uploaded_file($file['tmp_name'], $target_path)) {
            chmod($target_path, 0644);
            $uploaded++;
        } else {
            $errors[] = sprintf(__('Failed to upload %s', 'dtp-theme'), $file['name']);
        }
    }
    
    // Set admin notices
    if ($uploaded > 0) {
        add_settings_error(
            'dtp_butterchurn_files',
            'files_uploaded',
            sprintf(_n('%d file uploaded successfully.', '%d files uploaded successfully.', $uploaded, 'dtp-theme'), $uploaded),
            'success'
        );
    }
    
    if (!empty($errors)) {
        foreach ($errors as $error) {
            add_settings_error('dtp_butterchurn_files', 'upload_error', $error, 'error');
        }
    }
}
add_action('admin_init', 'dtp_handle_butterchurn_uploads');

/**
 * AJAX handler for deleting Butterchurn files
 */
function dtp_ajax_delete_butterchurn_file() {
    check_ajax_referer('dtp_visualizer_admin_nonce', 'nonce');
    
    if (!current_user_can('manage_options')) {
        wp_send_json_error(array('message' => __('Permission denied', 'dtp-theme')));
    }
    
    $filename = isset($_POST['filename']) ? sanitize_file_name($_POST['filename']) : '';
    $allowed_files = array('butterchurn.min.js', 'butterchurnPresets.min.js', 'butterchurnPresetsExtra.min.js');
    
    if (!in_array($filename, $allowed_files)) {
        wp_send_json_error(array('message' => __('Invalid file', 'dtp-theme')));
    }
    
    $file_path = get_template_directory() . '/assets/lib/' . $filename;
    
    if (file_exists($file_path) && unlink($file_path)) {
        wp_send_json_success(array('message' => __('File deleted successfully', 'dtp-theme')));
    } else {
        wp_send_json_error(array('message' => __('Failed to delete file', 'dtp-theme')));
    }
}
add_action('wp_ajax_dtp_delete_butterchurn_file', 'dtp_ajax_delete_butterchurn_file');

/**
 * Get Butterchurn file status
 */
function dtp_get_butterchurn_file_status() {
    $lib_dir = get_template_directory() . '/assets/lib/';
    $files = array(
        'butterchurn.min.js' => __('Butterchurn Core', 'dtp-theme'),
        'butterchurnPresets.min.js' => __('Butterchurn Presets', 'dtp-theme'),
        'butterchurnPresetsExtra.min.js' => __('Butterchurn Presets Extra', 'dtp-theme'),
    );
    
    $status = array();
    foreach ($files as $filename => $label) {
        $file_path = $lib_dir . $filename;
        $exists = file_exists($file_path);
        $size = $exists ? filesize($file_path) : 0;
        
        $status[$filename] = array(
            'label' => $label,
            'exists' => $exists,
            'size' => $size,
            'size_formatted' => $exists ? size_format($size) : '',
        );
    }
    
    return $status;
}

/**
 * Render admin page for Visualizer settings
 */
function dtp_visualizer_admin_page() {
    if (!current_user_can('manage_options')) {
        wp_die(__('You do not have sufficient permissions to access this page.', 'dtp-theme'));
    }
    
    settings_errors('dtp_butterchurn_files');
    
    $file_status = dtp_get_butterchurn_file_status();
    $all_files_exist = array_reduce($file_status, function($carry, $file) {
        return $carry && $file['exists'];
    }, true);
    
    ?>
    <div class="wrap dtp-visualizer-admin">
        <h1><?php echo esc_html(get_admin_page_title()); ?></h1>
        
        <div class="dtp-file-upload-section">
            <h2><?php _e('Butterchurn Library Files', 'dtp-theme'); ?></h2>
            <p class="description">
                <?php _e('Upload the Butterchurn library files required for the visualizer to work. These files should be copied from your React project\'s public/lib/ directory.', 'dtp-theme'); ?>
            </p>
            
            <?php if ($all_files_exist): ?>
                <div class="notice notice-success inline">
                    <p><strong><?php _e('✓ All required files are present.', 'dtp-theme'); ?></strong></p>
                </div>
            <?php else: ?>
                <div class="notice notice-warning inline">
                    <p><strong><?php _e('⚠ Some required files are missing. Please upload them below.', 'dtp-theme'); ?></strong></p>
                </div>
            <?php endif; ?>
            
            <table class="form-table dtp-file-status-table">
                <thead>
                    <tr>
                        <th><?php _e('File', 'dtp-theme'); ?></th>
                        <th><?php _e('Status', 'dtp-theme'); ?></th>
                        <th><?php _e('Size', 'dtp-theme'); ?></th>
                        <th><?php _e('Actions', 'dtp-theme'); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($file_status as $filename => $info): ?>
                        <tr>
                            <td><strong><?php echo esc_html($info['label']); ?></strong><br><code><?php echo esc_html($filename); ?></code></td>
                            <td>
                                <?php if ($info['exists']): ?>
                                    <span class="dtp-status-ok">✓ <?php _e('Present', 'dtp-theme'); ?></span>
                                <?php else: ?>
                                    <span class="dtp-status-missing">✗ <?php _e('Missing', 'dtp-theme'); ?></span>
                                <?php endif; ?>
                            </td>
                            <td><?php echo $info['exists'] ? esc_html($info['size_formatted']) : '—'; ?></td>
                            <td>
                                <?php if ($info['exists']): ?>
                                    <button type="button" 
                                            class="button dtp-delete-file" 
                                            data-filename="<?php echo esc_attr($filename); ?>">
                                        <?php _e('Delete', 'dtp-theme'); ?>
                                    </button>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
            
            <form method="post" enctype="multipart/form-data" class="dtp-upload-form">
                <?php wp_nonce_field('dtp_upload_butterchurn_files', 'dtp_butterchurn_upload_nonce'); ?>
                
                <table class="form-table">
                    <tr>
                        <th scope="row">
                            <label for="butterchurn_file"><?php _e('Butterchurn Core', 'dtp-theme'); ?></label>
                        </th>
                        <td>
                            <input type="file" 
                                   id="butterchurn_file" 
                                   name="butterchurn_file" 
                                   accept=".js" />
                            <p class="description"><?php _e('Upload butterchurn.min.js', 'dtp-theme'); ?></p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">
                            <label for="butterchurn_presets_file"><?php _e('Butterchurn Presets', 'dtp-theme'); ?></label>
                        </th>
                        <td>
                            <input type="file" 
                                   id="butterchurn_presets_file" 
                                   name="butterchurn_presets_file" 
                                   accept=".js" />
                            <p class="description"><?php _e('Upload butterchurnPresets.min.js', 'dtp-theme'); ?></p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">
                            <label for="butterchurn_presets_extra_file"><?php _e('Butterchurn Presets Extra', 'dtp-theme'); ?></label>
                        </th>
                        <td>
                            <input type="file" 
                                   id="butterchurn_presets_extra_file" 
                                   name="butterchurn_presets_extra_file" 
                                   accept=".js" />
                            <p class="description"><?php _e('Upload butterchurnPresetsExtra.min.js', 'dtp-theme'); ?></p>
                        </td>
                    </tr>
                </table>
                
                <?php submit_button(__('Upload Files', 'dtp-theme'), 'primary', 'dtp_upload_butterchurn_files'); ?>
            </form>
        </div>
    </div>
    
    <style>
    .dtp-file-status-table { margin-top: 20px; }
    .dtp-file-status-table th, .dtp-file-status-table td { padding: 10px; }
    .dtp-status-ok { color: #46b450; }
    .dtp-status-missing { color: #dc3232; }
    </style>
    
    <script>
    jQuery(document).ready(function($) {
        $('.dtp-delete-file').on('click', function() {
            if (!confirm('<?php echo esc_js(__('Are you sure you want to delete this file?', 'dtp-theme')); ?>')) {
                return;
            }
            
            var $button = $(this);
            var filename = $button.data('filename');
            
            $.ajax({
                url: ajaxurl,
                type: 'POST',
                data: {
                    action: 'dtp_delete_butterchurn_file',
                    filename: filename,
                    nonce: '<?php echo wp_create_nonce('dtp_visualizer_admin_nonce'); ?>'
                },
                success: function(response) {
                    if (response.success) {
                        location.reload();
                    } else {
                        alert(response.data.message || 'Error deleting file');
                    }
                },
                error: function() {
                    alert('Error deleting file');
                }
            });
        });
    });
    </script>
    <?php
}

/**
 * Enqueue Butterchurn scripts if files exist
 */
function dtp_enqueue_butterchurn_scripts() {
    $lib_dir = get_template_directory() . '/assets/lib/';
    $lib_url = get_template_directory_uri() . '/assets/lib/';
    $theme_version = '1.0.1';
    
    // Enqueue Butterchurn core
    if (file_exists($lib_dir . 'butterchurn.min.js')) {
        wp_enqueue_script(
            'butterchurn',
            $lib_url . 'butterchurn.min.js',
            array(),
            $theme_version,
            true
        );
    }
    
    // Enqueue Butterchurn presets
    if (file_exists($lib_dir . 'butterchurnPresets.min.js')) {
        wp_enqueue_script(
            'butterchurn-presets',
            $lib_url . 'butterchurnPresets.min.js',
            array('butterchurn'),
            $theme_version,
            true
        );
    }
    
    // Enqueue Butterchurn presets extra
    if (file_exists($lib_dir . 'butterchurnPresetsExtra.min.js')) {
        wp_enqueue_script(
            'butterchurn-presets-extra',
            $lib_url . 'butterchurnPresetsExtra.min.js',
            array('butterchurn-presets'),
            $theme_version,
            true
        );
    }
    
    // Enqueue visualizer script
    wp_enqueue_script(
        'dtp-visualizer-script',
        get_template_directory_uri() . '/assets/js/visualizer.js',
        array('jquery', 'butterchurn', 'butterchurn-presets', 'butterchurn-presets-extra'),
        $theme_version,
        true
    );
    
    // Localize visualizer script
    wp_localize_script('dtp-visualizer-script', 'dtpVisualizer', array(
        'defaultPreset' => get_option('dtp_visualizer_default_preset', 'Flexi - mindblob mix'),
        'autoStart' => get_option('dtp_visualizer_auto_start', '1'),
    ));
    
    // Enqueue AJAX navigation script (for persistent player)
    wp_enqueue_script(
        'dtp-ajax-navigation',
        get_template_directory_uri() . '/assets/js/ajax-navigation.js',
        array('jquery'),
        $theme_version,
        true
    );
}
add_action('wp_enqueue_scripts', 'dtp_enqueue_butterchurn_scripts', 20);

/**
 * Visualizer Shortcode
 * 
 * Displays the visualizer canvas and preset selector. Only use this shortcode on pages where you want the visualizer.
 * Usage: [dtp_visualizer]
 */
function dtp_visualizer_shortcode($atts) {
    // Only output canvas if Butterchurn files are available
    $lib_dir = get_template_directory() . '/assets/lib/';
    if (!file_exists($lib_dir . 'butterchurn.min.js')) {
        return '<p style="color: #fff; padding: 20px;">Visualizer libraries not found. Please upload Butterchurn files via Theme Settings.</p>';
    }
    
    $output = '<div class="dtp-visualizer-wrapper">';
    $output .= '<canvas id="dtp-visualizer-canvas"></canvas>';
    $output .= '<div class="dtp-visualizer-controls">';
    $output .= '<select id="dtp-visualizer-select" class="dtp-visualizer-select">';
    $output .= '<option value="">Select Visualizer</option>';
    $output .= '</select>';
    $output .= '</div>';
    $output .= '</div>';
    
    return $output;
}
add_shortcode('dtp_visualizer', 'dtp_visualizer_shortcode');

