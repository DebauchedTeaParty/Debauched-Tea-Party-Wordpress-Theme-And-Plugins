# WordPress Customizer Guide

## Accessing the Customizer

1. Log in to WordPress admin
2. Go to **Appearance > Customize**
3. Or click **Customize** in the admin bar when viewing your site

## Available Customizations

### Logo

**Location**: Appearance > Customize > Site Identity

1. Click **Select Logo**
2. Upload your logo image or choose from media library
3. The logo will replace the default logo in the header
4. You can crop/resize the logo as needed

**To hide the logo**: Go to **Appearance > Customize > Navigation Settings** and uncheck "Show Logo"

### Social Media Links

**Location**: Appearance > Customize > Social Media Links

You can customize:
- **GitHub URL** - Your GitHub profile/page URL
- **Twitter/X URL** - Your Twitter/X profile URL  
- **Discord URL** - Your Discord server invite URL
- **Show Social Media Icons** - Toggle to show/hide all social icons

**To update**:
1. Go to **Appearance > Customize > Social Media Links**
2. Enter new URLs in the respective fields
3. Uncheck "Show Social Media Icons" to hide them
4. Click **Publish** to save changes

### Navigation Settings

**Location**: Appearance > Customize > Navigation Settings

- **Show Logo** - Toggle to show/hide the logo in the header

### Radio Player Settings

**Location**: Appearance > Customize > Radio Player Settings

- **Show Radio Player** - Toggle to show/hide the radio player bar
- **Radio API URL** - Base URL for your radio API
- **Radio API Key** - Optional API key for authentication
- **Default Volume** - Initial volume level (0.0 to 1.0)
- **Default Station ID** - Station ID to play by default

## How It Works

The theme uses WordPress Customizer settings to:
- Display your custom logo (if uploaded) or default logo
- Show/hide the logo
- Display social media icons with your custom URLs
- Show/hide social media icons

All changes are live-previewed in the Customizer before you publish them.

## Default Values

If you don't set custom values, the theme uses these defaults:
- **Logo**: Uses `/images/logo.png` from theme folder
- **GitHub URL**: `https://github.com/DebauchedTeaParty`
- **Twitter URL**: `https://x.com/DebauchedTea`
- **Discord URL**: `https://discord.gg/xn7EsByKUp`
- **Show Logo**: Enabled
- **Show Social Icons**: Enabled

## Tips

- You can preview changes before publishing
- Changes take effect immediately after clicking **Publish**
- All settings are stored in WordPress database
- You can reset to defaults by clearing the customizer settings

