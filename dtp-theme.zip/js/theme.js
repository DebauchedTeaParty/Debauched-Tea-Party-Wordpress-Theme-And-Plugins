/**
 * DTP Theme JavaScript
 */
(function($) {
    'use strict';

    function updateVisualizerCanvas() {
        // Check if canvas exists (shortcode must be present)
        const canvas = document.getElementById('dtp-visualizer-canvas');
        
        if (!canvas) {
            // No canvas, destroy instance if it exists
            if (window.dtpVisualizerInstance) {
                window.dtpVisualizerInstance.stopRender();
                window.dtpVisualizerInstance.hideCanvas();
                window.dtpVisualizerInstance = null;
            }
        }
        // If canvas exists, visualizer.js will handle initialization
    }

    $(document).ready(function() {
        // Set initial visualizer canvas state
        updateVisualizerCanvas();
        
        // Update on AJAX navigation
        $(document).on('dtp-ajax-navigation-complete', updateVisualizerCanvas);
    });

})(jQuery);

