<?php
/**
 * Template Name: Visualizer Page
 * 
 * Template for displaying the visualizer page
 *
 * @package DTP_Theme
 */

get_header();
?>

<!-- Visualizer Canvas (only on this page via shortcode) -->
<?php echo do_shortcode('[dtp_visualizer]'); ?>

<main id="main" class="site-main visualizer-page">
    <div class="visualizer-container">
        <?php
        while (have_posts()) {
            the_post();
            ?>
            <article id="post-<?php the_ID(); ?>" <?php post_class('visualizer-content'); ?>>
                <?php if (get_the_content()) : ?>
                    <div class="entry-content">
                        <?php the_content(); ?>
                    </div>
                <?php endif; ?>
            </article>
            <?php
        }
        ?>
    </div>
</main>

<style>
.visualizer-page {
    min-height: 100vh;
    display: flex;
    align-items: center;
    justify-content: center;
    position: relative;
    z-index: 2;
}

.visualizer-container {
    width: 100%;
    height: 100vh;
    position: relative;
}

.visualizer-content {
    position: relative;
    z-index: 3;
    padding: 20px;
    text-align: center;
}

.visualizer-content .entry-content {
    color: white;
    font-size: 1.1rem;
    line-height: 1.6;
}

</style>

<?php
get_footer();

