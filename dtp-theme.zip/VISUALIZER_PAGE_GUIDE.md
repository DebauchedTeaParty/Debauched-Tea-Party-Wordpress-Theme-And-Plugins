# How to Create a Visualizer Page

The theme includes a custom page template for displaying the visualizer. Here's how to use it:

## Step-by-Step Instructions

### Step 1: Create a New Page

1. Log in to your WordPress admin dashboard
2. Go to **Pages > Add New**
3. Enter a title for your page (e.g., "Visualiser" or "Visualizer")
4. You can add content if you want text to appear over the visualizer (optional)

### Step 2: Select the Visualizer Template

1. In the page editor, look for the **Page Attributes** box on the right sidebar
2. If you don't see it, click the **three dots (⋮)** in the top right and select **Preferences**
3. Under **Panels**, enable **Page Attributes**
4. In the **Page Attributes** box, find **Template**
5. Select **Visualizer Page** from the dropdown
6. Click **Publish** or **Update**

### Step 3: Add to Navigation Menu (Optional)

To add the visualizer page to your navigation:

1. Go to **Appearance > Menus**
2. Find your visualizer page in the **Pages** list
3. Check the box next to it
4. Click **Add to Menu**
5. Drag it to your desired position
6. Click **Save Menu**

### Step 4: Install Visualizer Plugin

The visualizer requires the **DTP Visualizer plugin** to work:

1. Install and activate the **DTP Visualizer** plugin
2. Go to **Settings > Visualizer**
3. Upload the Butterchurn library files:
   - `butterchurn.min.js`
   - `butterchurnPresets.min.js`
   - `butterchurnPresetsExtra.min.js`
4. Configure default preset and settings

### Step 5: Test the Page

1. Visit your visualizer page on the frontend
2. Start playing music using the radio player (bottom of page)
3. The visualizer should automatically appear and start animating

## How It Works

- The **Visualizer Page** template automatically shows the visualizer canvas
- The canvas appears behind any content you add to the page
- The visualizer starts/stops automatically when you play/pause the radio
- You can change visualizer presets using the selector in the radio player bar

## Adding Content to the Visualizer Page

You can add content to the visualizer page:

1. Edit the page
2. Add text, images, or other content in the editor
3. The content will appear **on top of** the visualizer (with white text styling)
4. Use this for titles, descriptions, or instructions

Example content:
```
Welcome to the Visualiser

Play music using the radio player below to see the visualizations.
Use the visualizer selector in the player bar to change presets.
```

## Customizing the Visualizer Page

The visualizer page uses these CSS classes:
- `.visualizer-page` - Main container
- `.visualizer-container` - Full viewport container
- `.visualizer-content` - Content area (your page content)

You can customize the styling by adding CSS to **Appearance > Customize > Additional CSS** or by editing `style.css`.

## Troubleshooting

### Visualizer Not Showing

1. **Check plugin is active**: Go to **Plugins** and ensure DTP Visualizer is activated
2. **Check Butterchurn files**: Go to **Settings > Visualizer** and verify all 3 files are uploaded
3. **Check radio is playing**: The visualizer only shows when audio is playing
4. **Check browser console**: Look for JavaScript errors
5. **Verify WebGL2 support**: The visualizer requires WebGL2 (most modern browsers support this)

### Canvas Not Visible

- Ensure you selected **Visualizer Page** template
- Check that the page is published (not draft)
- Clear browser cache
- Verify the visualizer plugin is active

### Visualizer Not Animating

- Make sure the radio player is playing audio
- Check that audio context is initialized (browser console)
- Verify Butterchurn files are loaded (check Network tab)

## Quick Reference

**Template Name**: Visualizer Page  
**File**: `page-visualizer.php`  
**Location**: Theme root directory  
**Requires**: DTP Visualizer plugin + Butterchurn files  
**Works With**: Radio player (integrated in theme)

