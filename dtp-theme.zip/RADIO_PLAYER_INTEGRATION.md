# Radio Player Integration

The radio player is now **integrated directly into the theme** - you no longer need the separate plugin!

## Features

- ✅ Horizontal player bar at the bottom of all pages
- ✅ Play/Pause controls
- ✅ Volume control with slider
- ✅ Now playing track information
- ✅ Album art display
- ✅ Visualizer preset selector (works with Visualizer plugin)
- ✅ Fully customizable via WordPress Customizer

## Configuration

### Via WordPress Customizer

1. Go to **Appearance > Customize**
2. Click **Radio Player Settings**
3. Configure:
   - **Show Radio Player** - Toggle to show/hide the player
   - **Radio API URL** - Your radio API endpoint (default: https://radio.debauchedtea.party/api)
   - **Radio API Key** - Optional API key for authentication
   - **Default Volume** - Initial volume level (0.0 to 1.0)
   - **Default Station ID** - Station to play by default

4. Click **Publish** to save

### Default Settings

If not configured, the player uses:
- API URL: `https://radio.debauchedtea.party/api`
- Default Volume: `0.5`
- Default Station: `1`
- Player: **Enabled**

## How It Works

1. The player bar appears at the bottom of all pages
2. Click play to start the radio stream
3. Track information updates automatically every 10 seconds
4. Volume can be adjusted with the slider or mute button
5. Visualizer selector appears when the Visualizer plugin is active

## Integration with Visualizer Plugin

The radio player automatically integrates with the **DTP Visualizer plugin**:
- Visualizer preset selector appears in the player bar
- Audio context is shared between player and visualizer
- Visualizer automatically starts/stops with playback

## Disabling the Player

To hide the radio player:
1. Go to **Appearance > Customize > Radio Player Settings**
2. Uncheck **Show Radio Player**
3. Click **Publish**

## Troubleshooting

### Player Not Showing

- Check **Appearance > Customize > Radio Player Settings** - ensure "Show Radio Player" is enabled
- Clear browser cache
- Check browser console for JavaScript errors

### No Audio Playing

- Verify API URL is correct in Customizer
- Check API endpoints are accessible
- Verify API key if required
- Check browser console for errors

### Track Info Not Updating

- Verify the API endpoint `/nowplaying/{stationId}` is working
- Check browser console for API errors
- Ensure station ID is correct

## Files Included

The radio player is integrated into the theme:
- `assets/css/radio-player.css` - Player styles
- `assets/js/radio-player.js` - Player functionality
- `footer.php` - Player HTML markup
- `functions.php` - Customizer settings and enqueuing

No separate plugin needed!

