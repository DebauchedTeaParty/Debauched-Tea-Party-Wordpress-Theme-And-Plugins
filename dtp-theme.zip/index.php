<?php
/**
 * The main template file
 *
 * @package DTP_Theme
 */

get_header();
?>

<main id="main" class="site-main">
    <?php
    if (have_posts()) {
        while (have_posts()) {
            the_post();
            ?>
            <article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
                <div class="entry-content">
                    <?php the_content(); ?>
                </div>
            </article>
            <?php
        }
    } else {
        ?>
        <div class="no-content">
            <h1><?php esc_html_e('Nothing here', 'dtp-theme'); ?></h1>
            <p><?php esc_html_e('It looks like nothing was found at this location.', 'dtp-theme'); ?></p>
        </div>
        <?php
    }
    ?>
</main>

<?php
get_footer();

