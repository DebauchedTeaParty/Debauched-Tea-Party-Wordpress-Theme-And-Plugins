# WordPress Menu Setup Instructions

## Setting Up the Navigation Menu

### Step 1: Create a Menu

1. Log in to your WordPress admin dashboard
2. Go to **Appearance > Menus**
3. Click **Create a new menu**
4. Enter a name for your menu (e.g., "Main Navigation")
5. Click **Create Menu**

### Step 2: Add Pages to the Menu

1. In the left sidebar, you'll see available content:
   - **Pages** - Add existing pages
   - **Posts** - Add blog posts
   - **Custom Links** - Add custom URLs (like `/visualizer`)
   - **Categories** - Add post categories

2. Select the items you want in your menu:
   - Check the boxes next to pages/posts you want
   - Or use **Custom Links** to add:
     - URL: `/visualizer` (or full URL)
     - Link Text: `Visualiser`
     - Click **Add to Menu**

3. Drag and drop items to reorder them
4. Click **Save Menu**

### Step 3: Assign Menu Location

1. Scroll down to **Menu Settings**
2. Under **Display location**, check **Primary Menu**
3. Click **Save Menu**

### Step 4: Verify

1. Visit your website
2. The menu should appear in the navigation bar
3. Menu items will have hover effects and active state highlighting

## Customizing Menu Items

### Adding Custom Links

To add a link to the Visualizer page:
1. In **Appearance > Menus**
2. Click **Custom Links**
3. Enter:
   - **URL**: `/visualizer` or the full URL to your visualizer page
   - **Link Text**: `Visualiser`
4. Click **Add to Menu**
5. Save the menu

### Styling

The menu automatically uses the theme's styling:
- Hover effects (background color change, slight lift)
- Active page highlighting (blue gradient underline)
- Responsive design (stacks vertically on mobile)

## Troubleshooting

### Menu Not Showing

1. **Check menu assignment**: Go to **Appearance > Menus** and ensure "Primary Menu" is checked
2. **Check menu has items**: Make sure your menu has at least one item
3. **Clear cache**: If using a caching plugin, clear the cache

### Menu Items Not Styled Correctly

The theme automatically styles WordPress menus. If items look wrong:
1. Check that menu items are using the correct CSS classes
2. Verify the menu is assigned to "Primary Menu" location
3. Check browser console for CSS conflicts

### Adding More Menu Locations

If you need additional menu locations, you can add them in `functions.php`:

```php
register_nav_menus(array(
    'primary' => __('Primary Menu', 'dtp-theme'),
    'footer' => __('Footer Menu', 'dtp-theme'), // Example
));
```

Then assign menus in **Appearance > Menus** under the new location.

