# Debauched Tea Party WordPress Theme

A modern WordPress theme with radio player and visualizer support, compatible with Elementor.

## Installation

1. Upload the theme folder to `/wp-content/themes/`
2. Activate the theme through the 'Appearance' menu in WordPress
3. Install and activate the required plugins:
   - DTP Radio Player
   - DTP Visualizer

## Features

- Modern gradient background with animations
- Elementor page builder compatibility
- Custom navigation menu support
- Responsive design
- Visualizer canvas support

## Requirements

- WordPress 6.0 or higher
- PHP 7.4 or higher
- DTP Radio Player plugin
- DTP Visualizer plugin

## Customization

The theme uses standard WordPress customization options:
- Custom Logo (Appearance > Customize)
- Navigation Menu (Appearance > Menus)
- Elementor for page building

## Support

For support, visit https://debauchedtea.party

