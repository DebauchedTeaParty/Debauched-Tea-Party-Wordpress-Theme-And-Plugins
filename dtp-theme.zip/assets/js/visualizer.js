/**
 * DTP Visualizer JavaScript
 */
(function($) {
    'use strict';

    class DTPVisualizer {
        constructor() {
            this.canvas = null;
            this.visualizer = null;
            this.animationFrame = null;
            this.isPlaying = false;
            this.currentPreset = dtpVisualizer.defaultPreset || 'Flexi - mindblob mix';
            this.presets = {};
            this.isReady = false;
            
            this.init();
        }

        init() {
            // Only initialize if canvas exists (shortcode must be present)
            this.canvas = document.getElementById('dtp-visualizer-canvas');
            if (!this.canvas) {
                console.log('[DTP Visualizer] Canvas element not found (shortcode not used on this page)');
                return;
            }

            this.setupCanvas();
            this.waitForDependencies().then(() => {
                this.initializeVisualizer();
            });

            // Listen for radio player events
            window.addEventListener('dtp-radio-playing', (e) => {
                // Only respond if canvas exists
                if (!this.canvas) {
                    return;
                }
                this.isPlaying = e.detail.playing;
                this.updateRenderLoop();
            });
            
            // Also listen for when audio element becomes available
            this.waitForAudioElement();

            window.addEventListener('dtp-visualizer-change', (e) => {
                this.changePreset(e.detail.preset);
            });

            // Listen for page visibility changes
            document.addEventListener('visibilitychange', () => {
                if (document.hidden) {
                    this.pauseRender();
                } else {
                    // Recheck playing state when page becomes visible
                    this.checkPlayingState();
                    this.updateRenderLoop();
                }
            });
            
            // Listen for AJAX navigation to stop visualizer when leaving visualizer page
            $(document).on('dtp-ajax-navigation-complete', () => {
                const isVisualizerPage = document.body.classList.contains('page-template-page-visualizer');
                if (!isVisualizerPage) {
                    // We've navigated away from visualizer page - stop rendering
                    this.stopRender();
                    this.hideCanvas();
                } else {
                    // We're on visualizer page - ensure it's active
                    this.showCanvas();
                    this.checkPlayingState();
                    this.updateRenderLoop();
                }
            });
        }

        setupCanvas() {
            if (!this.canvas) return;

            this.canvas.width = window.innerWidth;
            this.canvas.height = window.innerHeight;

            // Handle resize
            window.addEventListener('resize', () => {
                if (this.canvas) {
                    this.canvas.width = window.innerWidth;
                    this.canvas.height = window.innerHeight;
                    if (this.visualizer) {
                        this.visualizer.setRendererSize(window.innerWidth, window.innerHeight);
                    }
                }
            });
        }

        waitForDependencies() {
            return new Promise((resolve, reject) => {
                let attempts = 0;
                const maxAttempts = 100; // 10 seconds max
                
                const checkDependencies = () => {
                    attempts++;
                    const butterchurn = window.butterchurn?.default || window.butterchurn;
                    const butterchurnPresets = window.butterchurnPresets?.default || window.butterchurnPresets;
                    const butterchurnPresetsExtra = window.butterchurnPresetsExtra?.default || window.butterchurnPresetsExtra;
                    const audioElement = window.__DTP_AUDIO_ELEMENT__;
                    const audioContext = window.__DTP_AUDIO_CONTEXT__;
                    const analyzer = window.__DTP_ANALYZER_NODE__;

                    // Debug logging
                    if (attempts === 1) {
                        console.log('[DTP Visualizer] Checking dependencies...');
                    }
                    
                    if (attempts % 10 === 0) {
                        console.log('[DTP Visualizer] Still waiting for dependencies:', {
                            butterchurn: !!butterchurn,
                            butterchurnPresets: !!butterchurnPresets,
                            butterchurnPresetsExtra: !!butterchurnPresetsExtra,
                            audioElement: !!audioElement,
                            audioContext: !!audioContext,
                            analyzer: !!analyzer
                        });
                    }

                    if (butterchurn && butterchurnPresets && audioElement && audioContext && analyzer) {
                        console.log('[DTP Visualizer] All dependencies loaded!');
                        // Store presets
                        const mainPresets = butterchurnPresets.getPresets?.() || {};
                        const extraPresets = butterchurnPresetsExtra?.getPresets?.() || {};
                        this.presets = { ...mainPresets, ...extraPresets };

                        console.log('[DTP Visualizer] Loaded', Object.keys(this.presets).length, 'presets');

                        // Send presets to radio player
                        if (window.dtpRadioPlayerInstance) {
                            window.dtpRadioPlayerInstance.setVisualizerPresets(Object.keys(this.presets));
                        }

                        resolve();
                    } else if (attempts >= maxAttempts) {
                        console.error('[DTP Visualizer] Timeout waiting for dependencies. Missing:', {
                            butterchurn: !butterchurn,
                            butterchurnPresets: !butterchurnPresets,
                            butterchurnPresetsExtra: !butterchurnPresetsExtra,
                            audioElement: !audioElement,
                            audioContext: !audioContext,
                            analyzer: !analyzer
                        });
                        reject(new Error('Timeout waiting for dependencies'));
                    } else {
                        setTimeout(checkDependencies, 100);
                    }
                };
                checkDependencies();
            });
        }

        initializeVisualizer() {
            if (!this.canvas) {
                console.error('[DTP Visualizer] Canvas element not found');
                return;
            }

            const butterchurn = window.butterchurn?.default || window.butterchurn;
            const gl = this.canvas.getContext('webgl2');
            
            if (!gl) {
                console.error('[DTP Visualizer] WebGL2 not available. Your browser may not support WebGL2.');
                return;
            }
            
            if (!butterchurn) {
                console.error('[DTP Visualizer] Butterchurn library not loaded. Please upload Butterchurn files via Appearance > Theme Settings in WordPress admin.');
                return;
            }

            try {
                console.log('[DTP Visualizer] Initializing visualizer...');
                
                // Get audio context - Butterchurn needs it as first parameter
                const audioContext = window.__DTP_AUDIO_CONTEXT__;
                if (!audioContext) {
                    console.error('[DTP Visualizer] Audio context not available');
                    return;
                }
                
                // Resume audio context if suspended
                if (audioContext.state === 'suspended') {
                    audioContext.resume().then(() => {
                        console.log('[DTP Visualizer] Audio context resumed');
                    }).catch(err => {
                        console.error('[DTP Visualizer] Failed to resume audio context:', err);
                    });
                }
                
                // Create visualizer - Butterchurn expects (audioContext, canvas, options)
                this.visualizer = butterchurn.createVisualizer(
                    audioContext,
                    this.canvas,
                    {
                        width: window.innerWidth,
                        height: window.innerHeight,
                        pixelRatio: window.devicePixelRatio || 1,
                    }
                );

                // Connect audio analyzer
                const analyzer = window.__DTP_ANALYZER_NODE__;
                if (analyzer) {
                    this.visualizer.connectAudio(analyzer);
                    console.log('[DTP Visualizer] Audio analyzer connected');
                } else {
                    console.warn('[DTP Visualizer] Audio analyzer not available');
                }

                // Load default preset
                this.loadPreset(this.currentPreset);
                console.log('[DTP Visualizer] Loaded preset:', this.currentPreset);

                this.isReady = true;
                
                // Check if audio is already playing (check multiple sources)
                this.checkPlayingState();
                this.updateRenderLoop();
                
                console.log('[DTP Visualizer] Initialization complete. Ready:', this.isReady, 'Playing:', this.isPlaying);
            } catch (error) {
                console.error('[DTP Visualizer] Error initializing visualizer:', error);
            }
        }
        
        waitForAudioElement() {
            // Poll for audio element if not immediately available
            let attempts = 0;
            const maxAttempts = 50; // 5 seconds max
            
            const checkAudio = () => {
                const audioElement = window.__DTP_AUDIO_ELEMENT__;
                const wasPlaying = sessionStorage.getItem('dtp_radio_playing') === 'true';
                
                if (audioElement && wasPlaying) {
                    // Audio element exists and should be playing
                    if (!audioElement.paused) {
                        this.isPlaying = true;
                        this.updateRenderLoop();
                    } else {
                        // Audio should be playing but is paused - wait a bit more
                        attempts++;
                        if (attempts < maxAttempts) {
                            setTimeout(checkAudio, 100);
                        }
                    }
                } else if (wasPlaying && attempts < maxAttempts) {
                    // Should be playing but audio element not ready yet
                    attempts++;
                    setTimeout(checkAudio, 100);
                }
            };
            
            // Start checking after a short delay
            setTimeout(checkAudio, 500);
        }
        
        checkPlayingState() {
            console.log('[DTP Visualizer] Checking playing state...');
            
            // Check audio element directly
            const audioElement = window.__DTP_AUDIO_ELEMENT__;
            if (audioElement && !audioElement.paused) {
                console.log('[DTP Visualizer] Audio is playing (from audio element)');
                this.isPlaying = true;
                return;
            }
            
            // Check radio player instance
            const radioPlayer = window.dtpRadioPlayerInstance || window.__DTP_RADIO_PLAYER_INSTANCE__;
            if (radioPlayer && radioPlayer.isPlaying) {
                console.log('[DTP Visualizer] Audio is playing (from radio player instance)');
                this.isPlaying = true;
                return;
            }
            
            // Check sessionStorage
            const wasPlaying = sessionStorage.getItem('dtp_radio_playing') === 'true';
            if (wasPlaying) {
                console.log('[DTP Visualizer] Audio should be playing (from sessionStorage), waiting for audio to restore...');
                // Wait a bit for audio to restore, then check again
                setTimeout(() => {
                    const audioEl = window.__DTP_AUDIO_ELEMENT__;
                    if (audioEl && !audioEl.paused) {
                        console.log('[DTP Visualizer] Audio restored and playing');
                        this.isPlaying = true;
                        this.updateRenderLoop();
                    } else {
                        console.log('[DTP Visualizer] Audio not yet restored');
                    }
                }, 500);
            } else {
                console.log('[DTP Visualizer] Audio is not playing');
            }
        }

        loadPreset(presetName) {
            if (!this.visualizer || !presetName) return;

            const preset = this.presets[presetName];
            if (preset) {
                this.visualizer.loadPreset(preset, 0.0);
                this.currentPreset = presetName;
            }
        }

        changePreset(presetName) {
            this.loadPreset(presetName);
        }

        updateRenderLoop() {
            // Only render if canvas exists
            if (!this.canvas) {
                this.stopRender();
                this.hideCanvas();
                return;
            }
            
            if (this.isPlaying && this.visualizer && this.isReady) {
                this.startRender();
            } else {
                this.stopRender();
            }
        }

        startRender() {
            // Check if canvas still exists
            if (!this.canvas) {
                this.stopRender();
                this.hideCanvas();
                return;
            }
            
            // Check if instance still exists (might have been destroyed)
            if (!window.dtpVisualizerInstance || window.dtpVisualizerInstance !== this) {
                this.stopRender();
                this.hideCanvas();
                return;
            }
            
            if (this.animationFrame) return; // Already rendering

            const render = () => {
                // Check if canvas still exists on every frame
                if (!this.canvas || !document.getElementById('dtp-visualizer-canvas')) {
                    this.stopRender();
                    this.hideCanvas();
                    return;
                }
                
                // Also check if instance still exists (might have been destroyed)
                if (!window.dtpVisualizerInstance || window.dtpVisualizerInstance !== this) {
                    this.stopRender();
                    this.hideCanvas();
                    return;
                }
                
                if (this.visualizer && this.isPlaying) {
                    this.visualizer.render();
                    this.animationFrame = requestAnimationFrame(render);
                } else {
                    this.animationFrame = null;
                }
            };

            render();
            this.showCanvas();
        }

        stopRender() {
            if (this.animationFrame) {
                cancelAnimationFrame(this.animationFrame);
                this.animationFrame = null;
            }
            this.hideCanvas();
        }

        pauseRender() {
            if (this.animationFrame) {
                cancelAnimationFrame(this.animationFrame);
                this.animationFrame = null;
            }
        }

        showCanvas() {
            if (this.canvas) {
                this.canvas.style.display = 'block';
                this.canvas.style.visibility = 'visible';
                this.canvas.style.opacity = '1';
                this.canvas.classList.add('active');
            }
        }

        hideCanvas() {
            if (this.canvas) {
                this.canvas.style.display = 'none';
                this.canvas.style.visibility = 'hidden';
                this.canvas.style.opacity = '0';
                this.canvas.classList.remove('active');
            }
        }

        // Public method to show visualizer on specific page
        showOnPage() {
            this.showCanvas();
            this.updateRenderLoop();
        }

        // Public method to hide visualizer
        hide() {
            this.hideCanvas();
            this.stopRender();
        }
    }

    // Expose class globally for AJAX navigation
    window.DTPVisualizer = DTPVisualizer;

    // Initialize when DOM is ready - ONLY if canvas exists (shortcode present)
    $(document).ready(function() {
        const canvas = document.getElementById('dtp-visualizer-canvas');
        
        if (canvas) {
            // Canvas exists (shortcode was used), create visualizer instance
            window.dtpVisualizerInstance = new DTPVisualizer();
        } else {
            // No canvas, make sure no instance exists
            if (window.dtpVisualizerInstance) {
                window.dtpVisualizerInstance.stopRender();
                window.dtpVisualizerInstance.hideCanvas();
                window.dtpVisualizerInstance = null;
            }
        }
    });

})(jQuery);

