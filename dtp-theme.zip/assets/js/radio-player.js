/**
 * DTP Radio Player JavaScript
 */
(function($) {
    'use strict';

    class DTPRadioPlayer {
        constructor() {
            // Try to restore from existing instance or sessionStorage
            const existingInstance = window.__DTP_RADIO_PLAYER_INSTANCE__;
            if (existingInstance && existingInstance.audioElement) {
                // Reuse existing audio element
                this.audioElement = existingInstance.audioElement;
                this.audioContext = existingInstance.audioContext;
                this.analyzer = existingInstance.analyzer;
                this.source = existingInstance.source;
                this.isPlaying = !existingInstance.audioElement.paused;
                this.volume = existingInstance.volume;
                this.currentStation = existingInstance.currentStation;
                this.currentTrack = existingInstance.currentTrack;
                this.stations = existingInstance.stations;
                
                // Restore UI state
                this.restoreUIState();
            } else {
                // New instance - check sessionStorage
                this.audioElement = null;
                this.audioContext = null;
                this.analyzer = null;
                this.source = null;
                this.isPlaying = false;
                this.volume = parseFloat(sessionStorage.getItem('dtp_radio_volume')) || dtpRadioPlayer.defaultVolume || 0.5;
                this.currentStation = sessionStorage.getItem('dtp_radio_station') || dtpRadioPlayer.defaultStation || '1';
                this.currentTrack = null;
                this.stations = [];
            }
            
            // Store instance globally
            window.__DTP_RADIO_PLAYER_INSTANCE__ = this;
            
            this.init();
        }

        init() {
            this.setupElements();
            this.setupEventListeners();
            
            // If we have an existing audio element, restore it
            if (this.audioElement && this.audioElement.src) {
                this.restoreAudioState();
            } else {
                // Fetch stations asynchronously
                this.fetchStations().then(() => {
                    // After stations are loaded, check if we should auto-play
                    const wasPlaying = sessionStorage.getItem('dtp_radio_playing') === 'true';
                    if (wasPlaying && this.stations.length > 0) {
                        this.initializeAudio();
                    }
                });
            }
            
            this.startNowPlayingPoll();
        }

        setupElements() {
            this.playPauseBtn = document.getElementById('dtp-play-pause');
            this.volumeSlider = document.getElementById('dtp-volume-slider');
            this.volumeToggle = document.getElementById('dtp-volume-toggle');
            this.trackTitle = document.getElementById('dtp-track-title');
            this.trackArtist = document.getElementById('dtp-track-artist');
            this.albumArt = document.getElementById('dtp-album-art');
            // Visualizer select is now in the visualizer wrapper, not in player bar
            // We'll find it when needed in setVisualizerPresets()
        }

        setupEventListeners() {
            if (this.playPauseBtn) {
                this.playPauseBtn.addEventListener('click', () => this.togglePlayPause());
            }

            if (this.volumeSlider) {
                this.volumeSlider.value = this.volume;
                this.volumeSlider.addEventListener('input', (e) => {
                    this.setVolume(parseFloat(e.target.value));
                });
            }

            if (this.volumeToggle) {
                this.volumeToggle.addEventListener('click', () => {
                    this.setVolume(this.volume === 0 ? 0.5 : 0);
                });
            }

            // Expose audio element to window for visualizer
            window.__DTP_AUDIO_ELEMENT__ = null;
            window.__DTP_AUDIO_CONTEXT__ = null;
            window.__DTP_ANALYZER_NODE__ = null;
            
            // Handle page visibility - restore playback if it was playing
            document.addEventListener('visibilitychange', () => {
                if (!document.hidden && this.audioElement) {
                    const wasPlaying = sessionStorage.getItem('dtp_radio_playing') === 'true';
                    if (wasPlaying && this.audioElement.paused) {
                        this.play().catch(err => console.error('Error restoring playback on visibility change:', err));
                    }
                }
            });
            
            // Preserve audio state before page unload
            const saveState = () => {
                if (this.audioElement) {
                    // Save current time and state
                    sessionStorage.setItem('dtp_radio_playing', (!this.audioElement.paused).toString());
                    sessionStorage.setItem('dtp_radio_volume', this.volume.toString());
                    sessionStorage.setItem('dtp_radio_station', this.currentStation);
                    sessionStorage.setItem('dtp_radio_current_time', this.audioElement.currentTime.toString());
                    // Try to keep audio context alive
                    if (this.audioContext && this.audioContext.state !== 'closed') {
                        // Don't close, let it persist
                    }
                }
            };
            
            window.addEventListener('beforeunload', saveState);
            window.addEventListener('pagehide', saveState);
            
            // Also save on visibility change
            document.addEventListener('visibilitychange', () => {
                if (document.hidden) {
                    saveState();
                }
            });
            
            // Pre-initialize audio on page load if it should be playing
            const wasPlaying = sessionStorage.getItem('dtp_radio_playing') === 'true';
            if (wasPlaying && !this.audioElement) {
                // Pre-fetch stations immediately
                this.fetchStations().then(() => {
                    if (this.stations.length > 0) {
                        this.initializeAudio();
                    }
                });
            }
        }

        async fetchStations() {
            try {
                const response = await fetch(`${dtpRadioPlayer.apiUrl}/stations`, {
                    headers: dtpRadioPlayer.apiKey ? {
                        'Authorization': `Bearer ${dtpRadioPlayer.apiKey}`
                    } : {}
                });
                
                if (response.ok) {
                    this.stations = await response.json();
                    if (this.stations.length > 0 && !this.audioElement) {
                        this.initializeAudio();
                    }
                }
            } catch (error) {
                console.error('Error fetching stations:', error);
            }
        }

        initializeAudio() {
            if (this.stations.length === 0) return;

            const station = this.stations.find(s => s.id === this.currentStation) || this.stations[0];
            
            // Only create new audio if we don't have one
            if (!this.audioElement || !this.audioElement.src) {
                this.audioElement = new Audio();
                this.audioElement.crossOrigin = 'anonymous';
                this.audioElement.src = station.listen_url;
                this.audioElement.volume = this.volume;
                this.audioElement.preload = 'auto'; // Preload for faster restoration
                
                // Setup audio context for visualizer
                if (!this.audioContext) {
                    this.audioContext = new (window.AudioContext || window.webkitAudioContext)();
                    this.analyzer = this.audioContext.createAnalyser();
                    this.analyzer.fftSize = 2048;

                    this.source = this.audioContext.createMediaElementSource(this.audioElement);
                    this.source.connect(this.analyzer);
                    this.source.connect(this.audioContext.destination);
                }
                
                // Handle audio element events for persistence
                this.audioElement.addEventListener('loadstart', () => {
                    sessionStorage.setItem('dtp_radio_loading', 'true');
                });
                
                this.audioElement.addEventListener('canplay', () => {
                    sessionStorage.removeItem('dtp_radio_loading');
                    // Auto-resume if it was playing
                    const wasPlaying = sessionStorage.getItem('dtp_radio_playing') === 'true';
                    if (wasPlaying && this.audioElement.paused) {
                        this.play().catch(() => {
                            // Ignore autoplay errors - user will need to click
                        });
                    }
                });
            } else {
                // Update volume if changed
                this.audioElement.volume = this.volume;
            }

            // Expose to window for visualizer immediately
            window.__DTP_AUDIO_ELEMENT__ = this.audioElement;
            window.__DTP_AUDIO_CONTEXT__ = this.audioContext;
            window.__DTP_ANALYZER_NODE__ = this.analyzer;

            // Update volume slider
            if (this.volumeSlider) {
                this.volumeSlider.value = this.volume;
            }
            
            // Restore playing state immediately if it was playing
            const wasPlaying = sessionStorage.getItem('dtp_radio_playing') === 'true';
            if (wasPlaying && this.audioElement.paused && this.audioElement.readyState >= 2) {
                // Only auto-play if audio is ready
                this.play().catch(() => {
                    // Autoplay blocked - user will need to click play
                    console.log('[DTP Radio] Autoplay blocked - user interaction required');
                });
            }
        }
        
        restoreAudioState() {
            // Restore volume
            if (this.audioElement) {
                this.audioElement.volume = this.volume;
                
                // Restore playback position if available
                const savedTime = sessionStorage.getItem('dtp_radio_current_time');
                if (savedTime && parseFloat(savedTime) > 0) {
                    this.audioElement.currentTime = parseFloat(savedTime);
                }
            }
            
            // Update UI
            this.updatePlayPauseButton();
            this.updateVolumeButton();
            
            if (this.volumeSlider) {
                this.volumeSlider.value = this.volume;
            }
            
            // Expose to window for visualizer immediately
            window.__DTP_AUDIO_ELEMENT__ = this.audioElement;
            window.__DTP_AUDIO_CONTEXT__ = this.audioContext;
            window.__DTP_ANALYZER_NODE__ = this.analyzer;
            
            // Check if we should restore playing state
            const wasPlaying = sessionStorage.getItem('dtp_radio_playing') === 'true';
            if (wasPlaying && this.audioElement) {
                // Resume audio context if suspended
                if (this.audioContext && this.audioContext.state === 'suspended') {
                    this.audioContext.resume().then(() => {
                        // Wait for audio to be ready
                        if (this.audioElement.readyState >= 2) {
                            this.play().catch(() => {
                                // Autoplay blocked - will need user interaction
                                console.log('[DTP Radio] Autoplay blocked on restore');
                            });
                        } else {
                            // Wait for audio to load
                            this.audioElement.addEventListener('canplay', () => {
                                this.play().catch(() => {
                                    console.log('[DTP Radio] Autoplay blocked after load');
                                });
                            }, { once: true });
                        }
                    });
                } else if (this.audioElement.paused) {
                    // Audio was playing, restore it if ready
                    if (this.audioElement.readyState >= 2) {
                        this.play().catch(() => {
                            console.log('[DTP Radio] Autoplay blocked');
                        });
                    } else {
                        // Wait for audio to load
                        this.audioElement.addEventListener('canplay', () => {
                            this.play().catch(() => {
                                console.log('[DTP Radio] Autoplay blocked after load');
                            });
                        }, { once: true });
                    }
                } else {
                    this.isPlaying = true;
                    this.updatePlayPauseButton();
                }
            } else {
                this.isPlaying = !this.audioElement.paused;
                this.updatePlayPauseButton();
            }
        }
        
        restoreUIState() {
            this.updatePlayPauseButton();
            this.updateVolumeButton();
            
            if (this.volumeSlider) {
                this.volumeSlider.value = this.volume;
            }
        }

        async togglePlayPause() {
            if (!this.audioElement) {
                this.initializeAudio();
            }

            try {
                if (this.isPlaying) {
                    await this.pause();
                } else {
                    await this.play();
                }
            } catch (error) {
                console.error('Error toggling playback:', error);
            }
        }

        async play() {
            if (!this.audioElement || !this.audioElement.src) {
                if (this.stations.length === 0) {
                    await this.fetchStations();
                }
                if (this.stations.length === 0) {
                    console.error('No stations available');
                    return;
                }
                this.initializeAudio();
            }

            try {
                if (this.audioContext && this.audioContext.state === 'suspended') {
                    await this.audioContext.resume();
                }
                await this.audioElement.play();
                this.isPlaying = true;
                this.updatePlayPauseButton();
                
                // Save state to sessionStorage
                sessionStorage.setItem('dtp_radio_playing', 'true');
                sessionStorage.setItem('dtp_radio_volume', this.volume.toString());
                sessionStorage.setItem('dtp_radio_station', this.currentStation);
                
                // Trigger custom event for visualizer
                window.dispatchEvent(new CustomEvent('dtp-radio-playing', { detail: { playing: true } }));
            } catch (error) {
                console.error('Error playing audio:', error);
                this.isPlaying = false;
                this.updatePlayPauseButton();
                sessionStorage.setItem('dtp_radio_playing', 'false');
            }
        }

        async pause() {
            if (this.audioElement) {
                await this.audioElement.pause();
                this.isPlaying = false;
                this.updatePlayPauseButton();
                
                // Save state to sessionStorage
                sessionStorage.setItem('dtp_radio_playing', 'false');
                
                // Trigger custom event for visualizer
                window.dispatchEvent(new CustomEvent('dtp-radio-playing', { detail: { playing: false } }));
            }
        }

        setVolume(volume) {
            this.volume = Math.max(0, Math.min(1, volume));
            
            if (this.audioElement) {
                this.audioElement.volume = this.volume;
            }

            if (this.volumeSlider) {
                this.volumeSlider.value = this.volume;
            }

            this.updateVolumeButton();
            
            // Save volume to sessionStorage
            sessionStorage.setItem('dtp_radio_volume', this.volume.toString());
        }

        updatePlayPauseButton() {
            if (!this.playPauseBtn) return;

            const playIcon = this.playPauseBtn.querySelector('.dtp-play-icon');
            const pauseIcon = this.playPauseBtn.querySelector('.dtp-pause-icon');

            if (this.isPlaying) {
                if (playIcon) playIcon.style.display = 'none';
                if (pauseIcon) pauseIcon.style.display = 'block';
            } else {
                if (playIcon) playIcon.style.display = 'block';
                if (pauseIcon) pauseIcon.style.display = 'none';
            }
        }

        updateVolumeButton() {
            if (!this.volumeToggle) return;

            const volumeUpIcon = this.volumeToggle.querySelector('.dtp-volume-up-icon');
            const volumeDownIcon = this.volumeToggle.querySelector('.dtp-volume-down-icon');

            if (this.volume === 0) {
                if (volumeUpIcon) volumeUpIcon.style.display = 'none';
                if (volumeDownIcon) volumeDownIcon.style.display = 'block';
            } else {
                if (volumeUpIcon) volumeUpIcon.style.display = 'block';
                if (volumeDownIcon) volumeDownIcon.style.display = 'none';
            }
        }

        async fetchNowPlaying() {
            if (!this.currentStation) return;

            try {
                const response = await fetch(`${dtpRadioPlayer.apiUrl}/nowplaying/${this.currentStation}`, {
                    headers: dtpRadioPlayer.apiKey ? {
                        'Authorization': `Bearer ${dtpRadioPlayer.apiKey}`
                    } : {}
                });

                if (response.ok) {
                    const data = await response.json();
                    this.updateTrackInfo(data);
                }
            } catch (error) {
                console.error('Error fetching now playing:', error);
            }
        }

        updateTrackInfo(data) {
            if (!data || !data.now_playing || !data.now_playing.song) return;

            const song = data.now_playing.song;
            this.currentTrack = {
                title: this.capitalizeText(song.title || 'Unknown Title'),
                artist: this.capitalizeText(song.artist || 'Unknown Artist'),
                album: this.capitalizeText(song.album || 'Unknown Album'),
                art: song.art || ''
            };

            if (this.trackTitle) {
                this.trackTitle.textContent = this.currentTrack.title;
            }

            if (this.trackArtist) {
                this.trackArtist.textContent = this.currentTrack.artist;
            }

            if (this.albumArt) {
                if (this.currentTrack.art) {
                    this.albumArt.src = this.currentTrack.art;
                    this.albumArt.style.display = 'block';
                } else {
                    this.albumArt.style.display = 'none';
                }
            }
        }

        capitalizeText(text) {
            return text
                .split(' ')
                .map(word => word.charAt(0).toUpperCase() + word.slice(1).toLowerCase())
                .join(' ');
        }

        startNowPlayingPoll() {
            // Fetch immediately
            this.fetchNowPlaying();
            
            // Then poll every 10 seconds
            setInterval(() => {
                this.fetchNowPlaying();
            }, 10000);
        }

        // Public method to set visualizer presets (called by visualizer plugin)
        setVisualizerPresets(presets) {
            // Find visualizer select in the visualizer wrapper (not in player bar)
            const visualizerSelect = document.getElementById('dtp-visualizer-select');
            if (!visualizerSelect) return;

            // Clear existing options except first
            while (visualizerSelect.options.length > 1) {
                visualizerSelect.remove(1);
            }

            // Add presets
            presets.forEach(preset => {
                const option = document.createElement('option');
                option.value = preset;
                option.textContent = preset.length > 30 ? `${preset.substring(0, 30)}...` : preset;
                visualizerSelect.appendChild(option);
            });

            // Show select if presets available
            if (presets.length > 0) {
                visualizerSelect.style.display = 'block';
                
                // Remove existing listener if any, then add new one
                const newSelect = visualizerSelect.cloneNode(true);
                visualizerSelect.parentNode.replaceChild(newSelect, visualizerSelect);
                
                // Add change listener to new select
                document.getElementById('dtp-visualizer-select').addEventListener('change', (e) => {
                    window.dispatchEvent(new CustomEvent('dtp-visualizer-change', {
                        detail: { preset: e.target.value }
                    }));
                });
            }
        }
    }

    // Initialize when DOM is ready
    $(document).ready(function() {
        window.dtpRadioPlayerInstance = new DTPRadioPlayer();
    });

})(jQuery);

