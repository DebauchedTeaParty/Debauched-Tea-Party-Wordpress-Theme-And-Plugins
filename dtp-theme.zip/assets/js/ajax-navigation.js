/**
 * AJAX Navigation for Persistent Player Bar
 * Loads page content without full page reload, keeping the player bar connected
 */
(function($) {
    'use strict';

    class DTPAjaxNavigation {
        constructor() {
            this.isLoading = false;
            this.init();
        }

        init() {
            // Only enable if player exists
            if (!document.getElementById('dtp-radio-player')) {
                return;
            }

            // Intercept all internal links
            $(document).on('click', 'a[href]', (e) => {
                const link = e.currentTarget;
                const href = $(link).attr('href');
                
                // Skip if:
                // - External link
                // - Already handled (e.g., download, target="_blank")
                // - Hash link (anchor)
                // - Admin/Login links
                // - AJAX disabled via data attribute
                if (!href || 
                    href.indexOf(window.location.origin) !== 0 ||
                    href.indexOf('#') === 0 ||
                    href.indexOf('/wp-admin') !== -1 ||
                    href.indexOf('/wp-login') !== -1 ||
                    link.target === '_blank' ||
                    link.hasAttribute('download') ||
                    $(link).data('no-ajax') === true ||
                    e.ctrlKey || e.metaKey || e.shiftKey) {
                    return;
                }

                e.preventDefault();
                this.loadPage(href);
            });

            // Handle browser back/forward buttons
            window.addEventListener('popstate', (e) => {
                if (e.state && e.state.url) {
                    this.loadPage(e.state.url, false); // Don't push state, we're already there
                }
            });
        }

        loadPage(url, pushState = true) {
            if (this.isLoading) return;
            
            this.isLoading = true;
            
            // Show loading indicator
            this.showLoading();
            
            // Save current scroll position
            sessionStorage.setItem('dtp_scroll_position', window.scrollY.toString());
            
            // Load page via AJAX
            $.ajax({
                url: url,
                type: 'GET',
                dataType: 'html',
                success: (data) => {
                    // Parse the response
                    const $newDoc = $(data);
                    
                    // Extract main content
                    const $newContent = $newDoc.find('#content, .site-content, main');
                    const newTitle = $newDoc.filter('title').text() || $newDoc.find('title').text();
                    
                    // Update page title
                    if (newTitle) {
                        document.title = newTitle;
                    }
                    
                    // Update main content area (everything except player and header)
                    // Make sure we don't replace the player bar or header
                    const $currentContent = $('#content, .site-content');
                    const $newMainContent = $newContent.filter('#content, .site-content').first();
                    
                    if ($currentContent.length && $newMainContent.length) {
                        // Only replace the content inside, not the wrapper
                        $currentContent.html($newMainContent.html());
                    } else if ($currentContent.length) {
                        // Fallback: replace the whole content area
                        $currentContent.replaceWith($newContent.filter('#content, .site-content').first());
                    }
                    
                    // Update any main elements that aren't the player
                    $('main:not(#dtp-radio-player)').each(function() {
                        const $this = $(this);
                        const $newMain = $newContent.find('main').first();
                        if ($newMain.length && $this.attr('id') !== 'dtp-radio-player') {
                            $this.html($newMain.html());
                        }
                    });
                    
                    // Update body classes
                    const newBodyClasses = $newDoc.filter('body').attr('class') || $newDoc.find('body').attr('class') || '';
                    if (newBodyClasses) {
                        document.body.className = newBodyClasses;
                    }
                    
                    // Check if canvas exists in new page (shortcode present)
                    const newCanvas = $newDoc.find('#dtp-visualizer-canvas');
                    const hasCanvas = newCanvas.length > 0;
                    
                    // If no canvas in new page, destroy instance
                    if (!hasCanvas && window.dtpVisualizerInstance) {
                        window.dtpVisualizerInstance.stopRender();
                        window.dtpVisualizerInstance.hideCanvas();
                        window.dtpVisualizerInstance = null;
                    }
                    
                    // Update header/navigation menu
                    const $newHeader = $newDoc.find('header, .dtp-navigation, #masthead').first();
                    const $currentHeader = $('header, .dtp-navigation, #masthead').first();
                    
                    if ($newHeader.length && $currentHeader.length) {
                        // Get the new navigation menu HTML
                        const $newNav = $newHeader.find('nav, .dtp-main-navigation, #site-navigation');
                        const $currentNav = $currentHeader.find('nav, .dtp-main-navigation, #site-navigation');
                        
                        if ($newNav.length && $currentNav.length) {
                            // Replace the navigation menu to get correct active states from WordPress
                            $currentNav.replaceWith($newNav.clone());
                        }
                        
                        // Also manually update active states based on current URL
                        const currentUrl = new URL(url, window.location.origin);
                        const currentPath = currentUrl.pathname;
                        
                        $currentHeader.find('.dtp-nav-menu a').each(function() {
                            const $link = $(this);
                            const $parent = $link.parent();
                            const href = $link.attr('href');
                            
                            if (href) {
                                try {
                                    const linkUrl = new URL(href, window.location.origin);
                                    const linkPath = linkUrl.pathname;
                                    
                                    // Remove existing active classes
                                    $parent.removeClass('current-menu-item current_page_item');
                                    
                                    // Check if this link matches current page
                                    if (linkPath === currentPath || 
                                        (currentPath === '/' && (linkPath === '/' || linkPath === '')) ||
                                        (currentPath !== '/' && linkPath === currentPath)) {
                                        $parent.addClass('current-menu-item current_page_item');
                                    }
                                } catch (e) {
                                    // Relative URL - compare paths directly
                                    const linkPath = href.split('?')[0]; // Remove query string
                                    $parent.removeClass('current-menu-item current_page_item');
                                    
                                    if (linkPath === currentPath || 
                                        (currentPath === '/' && (linkPath === '/' || linkPath === '')) ||
                                        (currentPath !== '/' && linkPath === currentPath)) {
                                        $parent.addClass('current-menu-item current_page_item');
                                    }
                                }
                            }
                        });
                    }
                    
                    // Handle visualizer canvas (only exists if shortcode is used)
                    const canvas = document.getElementById('dtp-visualizer-canvas');
                    
                    if (canvas) {
                        // Canvas exists (shortcode present) - initialize visualizer
                        if (!window.dtpVisualizerInstance && window.DTPVisualizer) {
                            window.dtpVisualizerInstance = new window.DTPVisualizer();
                        } else if (window.dtpVisualizerInstance) {
                            // Visualizer exists, re-initialize if needed
                            if (!window.dtpVisualizerInstance.canvas) {
                                window.dtpVisualizerInstance.init();
                            } else {
                                window.dtpVisualizerInstance.checkPlayingState();
                                window.dtpVisualizerInstance.updateRenderLoop();
                            }
                        }
                    } else {
                        // No canvas (shortcode not used) - destroy instance if it exists
                        if (window.dtpVisualizerInstance) {
                            window.dtpVisualizerInstance.stopRender();
                            window.dtpVisualizerInstance.hideCanvas();
                            window.dtpVisualizerInstance = null;
                        }
                    }
                    
                    // Push to history
                    if (pushState) {
                        window.history.pushState({ url: url }, newTitle, url);
                    }
                    
                    // Trigger WordPress events
                    $(document).trigger('dtp-ajax-navigation-complete');
                    
                    // Scroll to top or saved position
                    const savedScroll = sessionStorage.getItem('dtp_scroll_position');
                    if (savedScroll) {
                        window.scrollTo(0, parseInt(savedScroll));
                        sessionStorage.removeItem('dtp_scroll_position');
                    } else {
                        window.scrollTo(0, 0);
                    }
                    
                    // Hide loading
                    this.hideLoading();
                    this.isLoading = false;
                    
                    // Re-initialize any page-specific scripts if needed
                    this.reinitializePageScripts();
                },
                error: (xhr, status, error) => {
                    console.error('AJAX navigation error:', error);
                    // Fallback to normal navigation
                    window.location.href = url;
                }
            });
        }

        showLoading() {
            // Add loading class to body
            document.body.classList.add('dtp-ajax-loading');
            
            // Create or show loading indicator
            let $loader = $('.dtp-ajax-loader');
            if ($loader.length === 0) {
                $loader = $('<div class="dtp-ajax-loader"><div class="dtp-ajax-spinner"></div></div>');
                $('body').append($loader);
            }
            $loader.fadeIn(200);
        }

        hideLoading() {
            document.body.classList.remove('dtp-ajax-loading');
            $('.dtp-ajax-loader').fadeOut(200);
        }

        reinitializePageScripts() {
            // Re-run any scripts that need to run on page load
            // WordPress will handle most of this, but we can trigger custom events
            
            // Re-initialize visualizer if on visualizer page
            if (document.body.classList.contains('page-template-page-visualizer')) {
                if (window.dtpVisualizerInstance) {
                    // Visualizer should already be initialized, just ensure it's active
                    const canvas = document.getElementById('dtp-visualizer-canvas');
                    if (canvas) {
                        canvas.classList.add('active');
                    }
                }
            }
        }
    }

    // Initialize when DOM is ready
    $(document).ready(function() {
        // Enable AJAX navigation by default
        // Can be disabled by setting: sessionStorage.setItem('dtp_ajax_navigation', 'false')
        const ajaxNavEnabled = sessionStorage.getItem('dtp_ajax_navigation') !== 'false';
        if (ajaxNavEnabled) {
            window.dtpAjaxNavigation = new DTPAjaxNavigation();
            console.log('[DTP] AJAX navigation enabled - player bar will persist across page navigations');
        }
    });
    
    // Allow disabling AJAX navigation
    window.dtpDisableAjaxNavigation = function() {
        sessionStorage.setItem('dtp_ajax_navigation', 'false');
        if (window.dtpAjaxNavigation) {
            // Reload page to disable
            window.location.reload();
        }
    };
    
    // Allow enabling AJAX navigation
    window.dtpEnableAjaxNavigation = function() {
        sessionStorage.setItem('dtp_ajax_navigation', 'true');
        if (!window.dtpAjaxNavigation) {
            window.dtpAjaxNavigation = new DTPAjaxNavigation();
        }
    };

})(jQuery);

